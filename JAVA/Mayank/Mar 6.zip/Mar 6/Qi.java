import java.io.*;
import java.util.Scanner;
public class Qi
{
    Qi()
    {
        System.out.print("\nConstructor has been called \n");
    }
    public static void main(String[] args)
    {
    	Scanner scan = new Scanner(System.in);
    	Qi obj = new Qi();
        
    }	
}